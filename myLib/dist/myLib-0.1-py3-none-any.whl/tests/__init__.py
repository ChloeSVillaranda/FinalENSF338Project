from .testAVL import * 
from .testBST import *
from .testCDLL import * 
from .testCSLL import * 
from .testDLL import * 
from .testQueueLL import * 
from .testStackLL import * 
from .testSLL import * 

