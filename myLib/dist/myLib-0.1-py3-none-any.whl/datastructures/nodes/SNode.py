from myLib.datastructures.nodes import * 

class SNode:
    def __init__(self, data=None):
        self.data = data
        self.next = None